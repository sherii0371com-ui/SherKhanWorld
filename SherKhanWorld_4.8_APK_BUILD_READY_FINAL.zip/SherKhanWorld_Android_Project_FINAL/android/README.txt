شیر خان ورلڈ — Android project FINAL 1.1
Application ID: com.sherkhanworld.app

اس release میں:
- ایک ہی Bismillah start screen (HTML splash) رکھا گیا ہے؛ duplicate splash ختم۔
- Customer، Rider اور Admin dashboards برقرار ہیں۔
- Rider order accept کرتے وقت فوراً purchase amount کا 5% commission wallet سے deduct ہوتا ہے۔
- Commission کے لیے wallet balance کم ہو تو order accept نہیں ہوتا۔
- Android WebView کو backend API تک رسائی کے لیے درست کیا گیا ہے۔
- FastAPI backend میں CORS شامل ہے۔
- Order کا payment method اور delivery address backend کو بھیجے جاتے ہیں۔

اہم: یہ ابھی development/demo release ہے۔ Production کے لیے database persistence، حقیقی OTP/OAuth، payment gateway، secure authentication/authorization، image upload، اور server-side rider session management شامل کرنا ضروری ہے۔

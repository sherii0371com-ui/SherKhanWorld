# Sher Khan World — Release 3.9

## اس ریلیز میں
- Production API URL اب runtime پر تبدیل ہونے کے بعد اسی session میں فوراً استعمال ہوتا ہے؛ پہلے URL save ہونے کے باوجود پرانا value چل سکتا تھا۔
- Production API کے لیے صرف HTTPS URL قبول کیا جاتا ہے۔
- API Check اب response time، backend version اور storage status بھی دکھاتا ہے۔
- Backend health endpoint کو FINAL-3.9 اور feature list کے ساتھ update کیا گیا۔
- Android versionCode 29، versionName `3.9-production-setup`۔
- Owner photo، پورا پاکستان، markets، orders، Rider GPS، Customer/Rider/Admin flow اور flat 5% commission rule برقرار۔

## ابھی credentials درکار ہیں
- Real SMS OTP provider
- Production HTTPS server/database
- Easypaisa/JazzCash/online payment merchant credentials
- Firebase/FCM push notification credentials
- Signed AAB/Play Console testing

یہ credentials ZIP میں فرضی طور پر شامل نہیں کیے گئے۔

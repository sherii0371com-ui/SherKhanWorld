# Sher Khan World — Release 3.2

- App version: 3.2-final
- Added an in-app Privacy & Data Safety draft section.
- Added Privacy Policy viewing from the main navigation.
- Updated Android versionCode to 22.
- Backend version updated to FINAL-3.2.
- Existing customer/rider/admin, markets, Maps, notifications, order auto-refresh and 5% commission logic preserved.

## Important
This remains a development/project package. Before public Play Store launch, real OTP, production HTTPS API, secure authentication/authorization, payment gateway, production database, privacy-policy web URL and Play Console Data Safety declarations must be configured and tested.

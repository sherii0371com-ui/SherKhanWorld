# Sher Khan World — Release 4.7

- Previous VIP/colorful design retained.
- Android versionCode: 36.
- Release version: 4.7.
- Hardened Android WebView settings: disabled universal/file-to-file URL access and enabled Safe Browsing.
- Disabled Android app backup to reduce risk of local app-data exposure.
- HTTPS/cleartext restrictions remain enabled.
- Backend release/health version updated to FINAL-4.7.
- Existing 5% commission rule is unchanged: commission is deducted immediately when a rider accepts/selects an order; insufficient wallet balance blocks acceptance.
- Customer/Rider/Admin flows, Pakistan-wide service, live rider location and existing payment/OTP production configuration remain unchanged.

Production blockers that still require real owner/provider accounts: SMS OTP provider, production HTTPS server/API, payment gateway credentials/adapters, signed AAB and Play Console testing.

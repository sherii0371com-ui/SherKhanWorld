# Sher Khan World — Release 4.4

This release restores the previous Sher Khan World design from Release 4.2, as requested.

- Previous colorful/VIP visual design restored.
- All Release 4.2 production-control and app functionality retained.
- Whole Pakistan coverage retained.
- 5% flat commission rule retained: deducted immediately when a rider accepts/selects an order, with sufficient rider wallet balance required.
- Owner photo asset remains unchanged.
- Version code: 34
- Version name: 4.4-previous-design

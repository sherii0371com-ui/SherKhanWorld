# Sher Khan World — Release 4.2

## Production Control Center
- Android versionCode 32 / versionName `4.2-production-control-center`.
- Backend version updated to FINAL-4.2.
- Added `/production/checklist` for safe launch-readiness diagnostics without exposing credentials.
- Production checklist covers environment, OTP provider, payment provider, HTTPS policy, server-side secrets, 5% commission-on-accept, rider wallet precheck, Pakistan-wide service and live rider location.
- Existing owner photo, customer/rider/admin flow, markets, notifications, complaints, order tracking and payments remain intact.

## Important
Real OTP/payment credentials are not embedded. Live Easypaisa/JazzCash/online payments still require an approved provider account, server-side credentials and callback/webhook verification.

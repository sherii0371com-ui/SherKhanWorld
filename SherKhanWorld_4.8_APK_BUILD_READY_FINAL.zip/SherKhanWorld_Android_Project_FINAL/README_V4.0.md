# Sher Khan World — Release 4.0

## Production authentication & payment configuration scaffold
- Server-side OTP verification endpoint added: `/auth/otp/verify`.
- OTP development mode remains available for testing; production mode never exposes an OTP in the API response.
- Provider selection uses server environment variables: `SKW_OTP_PROVIDER` and `SKW_PAYMENT_PROVIDER`.
- `/config/status` reports configuration state without exposing secrets.
- Android API URL can be changed and becomes active immediately; production requires HTTPS.
- Version: 4.0, versionCode 30.

## Important
Real SMS OTP and Easypaisa/JazzCash/online payment processing are not activated without the provider credentials and server-side adapters. Do not put private API keys inside the Android app.

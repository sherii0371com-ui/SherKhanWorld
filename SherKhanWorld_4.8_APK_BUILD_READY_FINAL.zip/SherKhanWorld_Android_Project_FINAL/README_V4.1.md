# Sher Khan World — Release 4.1

## Production Readiness & Safety
- API/backend version updated to FINAL-4.1.
- Added `/release/status` to report launch-readiness checks without exposing secrets.
- Added a safe production configuration example (`production_config.example.json`).
- Android versionCode 31 / versionName `4.1-production-readiness`.
- HTTPS-only release policy remains enabled.
- 5% commission is still charged immediately when a rider accepts an order, with wallet-balance precheck.
- Pakistan-wide service model, rider GPS, complaints, notifications, markets, payments and order tracking remain intact.

## Important
This release does not invent or embed real OTP/payment credentials. Real SMS OTP and Easypaisa/JazzCash/online payment processing require the selected provider's server-side credentials and an approved production adapter.

## Before Play Store production
1. Set `SKW_ENV=production` on the server.
2. Set the real secure API base URL.
3. Configure an approved OTP/SMS provider.
4. Configure the selected payment provider and webhook/callback verification.
5. Run customer → rider → admin end-to-end tests.
6. Build and sign an Android App Bundle (AAB) with a real release keystore.

# Sher Khan World — Release 4.6

- Previous colorful/VIP design retained.
- Android versionCode: 35.
- Release version: 4.6.
- Added Launch Checklist/status UI and `/launch/summary` backend endpoint.
- Updated backend API version to FINAL-4.6 and release status version.
- Preserved Pakistan-wide service and the fixed 5% commission rule: commission is deducted immediately when a rider accepts/selects an order; insufficient rider wallet balance blocks acceptance.
- Core app flow remains Customer + Rider + Admin.

## What remains before a real Play Store launch
1. Real SMS OTP provider/account and server adapter.
2. Production HTTPS server/database and production API URL.
3. Easypaisa/JazzCash/online payment merchant integration.
4. Signed AAB + internal/closed Play Console testing.
5. Final public Privacy Policy/Data Safety/account-deletion setup.
6. Production security review and live-service testing.

These external steps require the owner's real accounts/credentials; passwords, OTPs, PINs, or private keys should never be shared in chat.

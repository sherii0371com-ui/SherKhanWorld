# Sher Khan World — V2.7 Push Notification Foundation

This version adds a backend notification inbox foundation for Customer/Rider/Admin flows.

Included:
- Notification record: recipient role/id, type, title, message, related order, read status.
- GET notifications for a recipient.
- Mark notification as read.
- Rider receives a `new_order` notification when an order is successfully matched.
- Existing V2.6 GPS/rider matching remains: 1 km → 2 → 5 → 10 → 20 km.

Important: this is a development backend foundation. Real Android push delivery (FCM or another provider), secure authentication, HTTPS hosting and production database are still required before launch.

# APK بنانے کا آسان طریقہ

پروجیکٹ GitHub پر upload کرنے کے بعد **Actions** کھولیں اور **Build Sher Khan World APK** منتخب کریں۔
Workflow مکمل ہونے پر **SherKhanWorld-debug-apk** artifact download کریں۔

یہ APK فون میں testing کے لیے ہے۔ Play Store کے لیے بعد میں signed AAB درکار ہوگا۔

# شیر خان ورلڈ — FINAL 1.1

یہ project وہی Sher Khan World app ہے، جس میں بنیادی Customer / Rider / Admin flow اور 5% rider commission rule شامل ہے۔

## اس release میں درست کی گئی اہم چیزیں
1. Bismillah start screen اب Android میں duplicate نہیں ہوگی۔
2. WebView کو local HTML سے backend API تک request کرنے کی اجازت دی گئی ہے۔
3. Backend میں CORS شامل کیا گیا ہے تاکہ API requests development environment میں کام کریں۔
4. Customer order بناتے وقت payment method اور delivery address بھی backend کو بھیجے جاتے ہیں۔
5. Backend کا version `FINAL-1.1` کر دیا گیا ہے۔
6. Rider commission rule: order accept کرتے ہی purchase amount کا 5% wallet سے فوراً deduct؛ insufficient wallet پر acceptance blocked۔

## Run
Backend:
`pip install -r backend/requirements.txt`
`uvicorn app:app --host 0.0.0.0 --port 8000`

Android:
Android Studio میں `android/` folder کھولیں اور Gradle sync/build کریں۔

## Production note
یہ release development/demo foundation ہے۔ Public launch سے پہلے persistent database، secure auth/roles، real OTP/OAuth credentials، payment gateway verification، image storage، HTTPS، logging/backups، اور server-side authorization لازمی مکمل کریں۔


### Release 1.5
- Backend order sync endpoint added.
- Existing customers are reused by phone when placing orders.
- Customer can cancel waiting/assigned orders.
- Rider availability and location update controls added.
- Admin refresh/sync controls added.
- 5% commission rule remains: charged immediately on rider acceptance, subject to sufficient wallet balance.

### Release 1.6
- Rider acceptance now verifies that an already-assigned order belongs to that rider.
- Wallet transaction history endpoint added for rider transparency.
- Android release metadata updated to 1.6-final.
- 5% commission remains charged immediately at rider acceptance, before the order can proceed.


## Release 1.8
- Rider order status updates now sync to backend with validated transitions.
- Completion returns the rider to available status.
- Customer/rider order-status notifications are generated on backend transitions.
- Android version: 1.8-final.
- The 5% commission is still charged immediately on order acceptance and requires sufficient rider wallet balance.


## Release 1.9
- Customer notifications inbox with read control.
- Automatic order/notification refresh every 30 seconds.
- Android version 1.9-final.
- Backend version FINAL-1.9.
- 5% commission rule unchanged: commission is charged immediately when rider accepts/selects the order and wallet must have sufficient balance.


### Release 2.1
- Rider dashboard endpoint added with wallet, active orders and unread notification count.
- Payment history by order endpoint added.
- Unread notification count endpoint added.
- Admin summary expanded with active orders, open complaints and unread admin notifications.
- Admin orders listing/filter endpoint added.
- Android version: 2.1-final.
- 5% commission rule unchanged: charged immediately at rider acceptance and requires sufficient wallet balance.


### Release 2.3
- Rider status endpoint added.
- A rider cannot accept a second active order while already handling one.
- Rider cannot be switched to available while an active order exists.
- Backend health version updated to FINAL-2.3.
- Android version: 2.3-final.
- 5% commission remains charged immediately at rider acceptance and requires sufficient wallet balance.


## Release 2.4
- Backend health version FINAL-2.4 and Android version 2.4-final.
- Admin finance summary endpoint added for commission, deposits and rider-wallet totals.
- Total commission reporting now comes from actual commission wallet transactions, so an order cancelled after acceptance does not erase an already-charged 5% commission from the financial total.
- 5% commission remains charged immediately at rider acceptance and requires sufficient rider wallet balance.


## Release 2.5
- Customer complaint form added; complaints notify Admin immediately through the backend.
- Admin complaints listing endpoint/UI added.
- Customer cancellation now notifies the assigned rider and Admin.
- Payment method validation added for Cash on Delivery, Easypaisa, JazzCash and Online Payment.
- Android version: 2.5-final; Backend version: FINAL-2.5.
- 5% commission rule unchanged: charged immediately at rider acceptance and requires sufficient rider wallet balance.


## Release 2.6 — Product Completion Pass
- Backend state is now persisted to `backend/sherkhanworld_state.json` after successful write requests, so demo/server restarts do not erase orders, riders, payments, complaints, notifications and wallet transactions.
- Backend health reports FINAL-2.6 and persistent JSON storage.
- Admin finance endpoint summarizes commissions, deposits, rider wallets and payment totals.
- Android version: 2.6-final.
- 5% commission rule unchanged: deducted immediately at rider acceptance and requires sufficient rider wallet balance.
- This remains a launch-ready development package; real OTP/OAuth, payment gateway credentials, HTTPS, secure server-side authentication/authorization and a production database are still required before public deployment.


## Release 3.0
- Customer order status auto-refresh ہر 15 سیکنڈ بعد شامل۔
- Notifications auto-refresh شامل۔
- Version 3.0-final.
- 5% commission acceptance rule برقرار۔


## Release 3.6
آپ کی فراہم کردہ اصل تصویر ایپ کے launch screen، header اور Owner Profile میں شامل کی گئی ہے۔


### Release 4.1
Production readiness checks اور secure configuration example شامل کیا گیا ہے۔ حقیقی OTP/payment credentials جان بوجھ کر شامل نہیں کیے گئے۔

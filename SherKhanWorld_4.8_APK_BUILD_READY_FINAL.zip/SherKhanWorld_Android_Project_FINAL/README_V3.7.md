# Sher Khan World — Release 3.7

## اس ریلیز میں
- Release version کو `3.7-production-ready` اور versionCode `27` کیا گیا ہے۔
- Release build میں Android cleartext HTTP traffic بند کر دی گئی ہے؛ production API کے لیے HTTPS ضروری ہوگا۔
- API URL کی موجودہ setting برقرار ہے، تاکہ production server URL بعد میں داخل کیا جا سکے۔
- Owner کی اصل تصویر، Bismillah launch screen، header/profile، پورا پاکستان، markets، order tracking اور flat 5% rider commission rule برقرار ہیں۔
- Rider order قبول کرتے وقت 5% commission فوراً wallet سے deduct ہونے اور ناکافی balance پر acceptance block ہونے کا موجودہ logic برقرار ہے۔

## Production میں ابھی credentials درکار ہیں
1. HTTPS production API/server
2. Real SMS OTP provider
3. Live GPS/maps key/configuration
4. Easypaisa/JazzCash/online payment merchant credentials
5. Firebase/FCM push notification configuration
6. Signed Play App Bundle (AAB) اور Play Console testing

یہ credentials اس ZIP میں فرضی طور پر شامل نہیں کیے گئے۔

# Sher Khan World — Release 3.5

## اس ریلیز میں
- Customer order tracking timeline بہتر کیا گیا۔
- آخری order sync وقت دکھایا جاتا ہے۔
- Customer موجودہ Order ID ایک بٹن سے copy کر سکتا ہے۔
- پہلے سے موجود markets, sharing, privacy/data deletion, notifications اور Customer/Rider/Admin flows برقرار ہیں۔
- Rider acceptance پر flat 5% commission اور ناکافی wallet balance پر acceptance block برقرار ہے۔

## Production کے باقی کام
Real SMS OTP, HTTPS production API/database, secure authentication, live GPS configuration, real Easypaisa/JazzCash/online payment gateway, public privacy policy URL, signed AAB اور Play Console testing/review ابھی ضروری ہیں۔

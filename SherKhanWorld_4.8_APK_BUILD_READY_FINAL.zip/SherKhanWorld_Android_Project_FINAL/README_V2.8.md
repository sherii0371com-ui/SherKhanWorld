# Sher Khan World — V2.8 Market Finder

This release continues the Pakistan marketplace work.

## Added
- Search box for major markets.
- City filter for the market list.
- Market cards retain product categories and Google Maps links.
- Whole-Pakistan badge and marketplace flow remain unchanged.
- Existing customer, rider and admin flows are preserved.

## Commission rule
The rider commission remains a flat 5% of the purchase/order amount. It is deducted immediately when the rider accepts/selects the order, and the rider must have enough wallet balance before acceptance.

## Important
This is still an Android project/prototype package, not a production-live Play Store release. Real OTP, live GPS, payment gateways, HTTPS hosting, production database and secure admin authentication must be connected before public launch.

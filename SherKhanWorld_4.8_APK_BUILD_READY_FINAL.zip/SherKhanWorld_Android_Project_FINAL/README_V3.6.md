# Sher Khan World — Release 3.6

## اس ریلیز میں
- صارف کی فراہم کردہ اصل تصویر `sher_khan_owner_photo.png` کے طور پر ایپ میں شامل کی گئی ہے۔
- تصویر میں چہرے یا جسم کی کوئی AI تبدیلی نہیں کی گئی؛ اصل تصویر ہی استعمال ہوئی ہے۔
- Bismillah launch screen، app header اور Owner Profile card میں یہی تصویر دکھائی جاتی ہے۔
- Sher Khan World برانڈ اور پورا پاکستان سروس ماڈل برقرار ہے۔
- Rider acceptance پر flat 5% commission اور ناکافی wallet balance پر acceptance block برقرار ہے۔
- Release version: 3.6-owner-profile (versionCode 26)۔

## اگلا production مرحلہ
Real OTP، HTTPS production API/database، live GPS، real Easypaisa/JazzCash/online payment gateway، signed AAB اور Play Console testing ابھی الگ production credentials/server کے ساتھ مکمل کیے جائیں گے۔

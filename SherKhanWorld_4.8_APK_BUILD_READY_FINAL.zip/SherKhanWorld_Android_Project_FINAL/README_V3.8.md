# Sher Khan World — Release 3.8

## اس ریلیز میں
- Android native **Live GPS Location** bridge شامل کیا گیا ہے۔ Rider dashboard سے Live GPS Location دبانے پر app device کی location permission مانگتی ہے اور GPS/network location حاصل کر کے backend `/riders/location` پر بھیجتی ہے۔
- Location permission: ACCESS_FINE_LOCATION اور ACCESS_COARSE_LOCATION۔
- Rider کا manual latitude/longitude update fallback برقرار ہے۔
- Production API URL کو local default سے ہٹا کر explicit HTTPS configuration بنایا گیا ہے؛ `⚙️ API URL` سے اپنا production HTTPS server address محفوظ کیا جا سکتا ہے۔
- Release version `3.8-live-location-ready`، versionCode `28`۔
- Owner photo، پورا پاکستان، markets، orders، customer/rider/admin flow اور flat 5% commission rule برقرار۔

## ابھی بھی اصل production credentials درکار ہیں
1. HTTPS backend/server URL
2. Real SMS OTP provider
3. Easypaisa/JazzCash/online payment merchant credentials
4. Firebase/FCM push notification configuration
5. Signed Play App Bundle (AAB) اور Play Console testing

یہ credentials ZIP میں فرضی طور پر شامل نہیں کیے گئے۔

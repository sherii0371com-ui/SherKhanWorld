# Sher Khan World — Release 2.9

## اس ریلیز میں
- App version: 2.9-final
- Sher Khan World کا تعارف اور بنیادی استعمال کی مدد شامل۔
- Play Store کے لیے مستقبل کا share-link action شامل۔
- پاکستان بھر، مارکیٹس، Maps، Customer/Rider/Admin flows اور 5% commission rule برقرار۔

## اہم مالی اصول
Rider order قبول کرتے وقت خریداری رقم کا flat 5% commission فوراً wallet سے deduct ہوتا ہے۔ Wallet میں کافی balance نہ ہو تو order قبول نہیں ہوتا۔

## Play Store readiness
یہ ابھی production-live Play Store app نہیں ہے۔ Final release سے پہلے signed AAB، حقیقی SMS OTP، production authentication، HTTPS API/server، live GPS/location، حقیقی Easypaisa/JazzCash/online payment gateway، production database، admin security، privacy policy URL اور Google Play required declarations مکمل کرنا ہوں گے۔

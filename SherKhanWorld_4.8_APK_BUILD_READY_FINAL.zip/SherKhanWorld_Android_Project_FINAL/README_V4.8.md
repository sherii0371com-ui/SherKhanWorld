# Sher Khan World — Release 4.8

## مقصد
یہ release موجودہ VIP/rangین design اور موجودہ functionality کو برقرار رکھتے ہوئے Android build کے لیے آخری preparation step ہے۔ اس release میں کوئی نیا customer/rider/admin feature شامل نہیں کیا گیا۔

## Version
- App version: 4.8-vip-build-ready
- Android versionCode: 37
- Backend release: 4.8

## Build target
Android project: `android/`
Application ID: `com.sherkhanworld.app`
compileSdk: 35
minSdk: 23
targetSdk: 35

## اہم اصول برقرار
- Sher Khan World
- پورا پاکستان
- Customer / Rider / Admin flows
- Rider wallet شرط
- flat 5% commission
- 5% commission rider کے order accept/select کرتے وقت فوراً deduct ہوتی ہے
- commission کے لیے wallet میں پہلے سے کافی balance ضروری ہے
- موجودہ VIP/rangین design برقرار

## اگلا مرحلہ
اس project کو Android build environment میں debug APK کے لیے build/test کیا جائے، پھر release signing کے بعد AAB تیار کیا جائے۔ اس environment میں Gradle/Android SDK دستیاب نہ ہونے کی وجہ سے یہاں APK binary خود build نہیں کی گئی؛ project کو build-ready رکھا گیا ہے۔

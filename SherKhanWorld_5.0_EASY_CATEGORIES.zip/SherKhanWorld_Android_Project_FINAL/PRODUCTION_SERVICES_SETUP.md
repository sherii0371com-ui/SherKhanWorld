# Sher Khan World — Production Services Setup

The app now contains the production-ready integration points for:
- Phone OTP provider
- Easypaisa/JazzCash/online payment requests
- Rider wallet and payout requests
- Motorcycle/rickshaw/car/van ride booking and driver matching
- 5% rider commission charged immediately on order acceptance
- Pakistan-wide service area

Live provider activation still requires the owner's own provider accounts, API credentials, and a real HTTPS backend. Private keys must be stored as server environment variables, never inside the Android app.

Environment variables used by the backend:
- `SKW_ENV=production`
- `SKW_OTP_PROVIDER=<provider-name>`
- `SKW_PAYMENT_PROVIDER=<provider-name>`

Do not put real API secrets in `index.html`, APK assets, GitHub, or the ZIP.

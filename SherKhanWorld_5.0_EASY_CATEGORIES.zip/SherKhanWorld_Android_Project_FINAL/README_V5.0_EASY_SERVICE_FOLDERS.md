# Sher Khan World 5.0 — Easy Service Folders

چار واضح Customer service folders شامل کیے گئے ہیں:

1. 🛍️ بازار / خریداری — customer چیز منگواتا ہے۔
2. 🍛 کھانا / سبزی — food, grocery اور vegetables۔
3. 🏍️ ڈیلیوری رائیڈر — rider بازار سے چیز لا کر customer کو دیتا ہے۔
4. 🚕 رائیڈ بکنگ / سفر — driver customer کو خود pickup کرکے destination تک لے جاتا ہے۔

مقصد: Customer کو پہلی نظر میں فرق سمجھ آ جائے کہ **Delivery Rider چیز لاتا ہے** اور **Ride Driver مسافر کو لے جاتا ہے**۔

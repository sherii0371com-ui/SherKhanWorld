package com.sherkhanworld.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int LOCATION_REQUEST = 4108;
    private WebView web;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openMainApp();
    }

    private void openMainApp() {
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowFileAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        web.addJavascriptInterface(new NativeBridge(), "SherKhanNative");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private void requestNativeLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_REQUEST);
            return;
        }
        startSingleLocationRequest();
    }

    private void startSingleLocationRequest() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager == null) {
            sendLocationError("Location service دستیاب نہیں ہے۔");
            return;
        }
        String provider = LocationManager.GPS_PROVIDER;
        try {
            if (!locationManager.isProviderEnabled(provider)) provider = LocationManager.NETWORK_PROVIDER;
            final String selectedProvider = provider;
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(@NonNull Location location) {
                    sendLocation(location.getLatitude(), location.getLongitude());
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
                }
                @Override public void onProviderDisabled(@NonNull String provider) {}
                @Override public void onProviderEnabled(@NonNull String provider) {}
            };
            locationManager.requestLocationUpdates(selectedProvider, 0L, 0f, locationListener, Looper.getMainLooper());
            Location last = locationManager.getLastKnownLocation(selectedProvider);
            if (last != null) sendLocation(last.getLatitude(), last.getLongitude());
        } catch (SecurityException e) {
            sendLocationError("Location permission درکار ہے۔");
        } catch (Exception e) {
            sendLocationError("Location حاصل نہیں ہو سکی۔");
        }
    }

    private void sendLocation(double lat, double lon) {
        if (web == null) return;
        web.post(() -> web.evaluateJavascript("window.onNativeLocation && window.onNativeLocation(" + lat + "," + lon + ");", null));
    }

    private void sendLocationError(String message) {
        if (web == null) return;
        web.post(() -> web.evaluateJavascript("window.onNativeLocationError && window.onNativeLocationError(" + quoteJs(message) + ");", null));
    }

    private String quoteJs(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'";
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) startSingleLocationRequest();
            else sendLocationError("Location permission اجازت نہیں ملی۔");
        }
    }

    public class NativeBridge {
        @JavascriptInterface public void requestLocation() { runOnUiThread(() -> requestNativeLocation()); }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
